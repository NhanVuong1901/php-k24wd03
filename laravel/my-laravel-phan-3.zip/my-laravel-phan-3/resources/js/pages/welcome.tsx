function welcome() {
    return <div>welcome</div>;
}

export default welcome;
