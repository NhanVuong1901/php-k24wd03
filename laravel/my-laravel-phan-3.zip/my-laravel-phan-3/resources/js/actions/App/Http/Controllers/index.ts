import StudentTopController from './StudentTopController'
const Controllers = {
    StudentTopController,
}

export default Controllers