import BookController from './BookController'
import Settings from './Settings'
import Auth from './Auth'
const Controllers = {
    BookController,
Settings,
Auth,
}

export default Controllers