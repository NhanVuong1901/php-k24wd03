import ProfileController from './ProfileController'
import PasswordController from './PasswordController'
const Settings = {
    ProfileController,
PasswordController,
}

export default Settings